﻿using Microsoft.Win32;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.IO;
namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }
        class Osoba
        {
            public string? m_strPESEL { get; set; }
            public string? m_strName { get; set; }
            public string? m_strSecName { get; set; }
            public string? m_strSname { get; set; }
            public string? m_strData { get; set; }
            public string? m_strAdres { get; set; }
            public string? m_strMiejsce { get; set; }
            public string? m_strKod { get; set; }

            public Osoba()
            {
                m_strPESEL = "00000000000";
                m_strName = "";
                m_strSecName = "";
                m_strSname = "";
                m_strData = "";
                m_strAdres = "";
                m_strMiejsce = "";
                m_strKod = "";
            }
        }
        private void btn_dodaj(object sender, RoutedEventArgs e)
        {
            Dodaj_lista lista_dodaj = new Dodaj_lista();
            lista_dodaj.ShowDialog();
            Osoba osoba = new Osoba();
            var rnd = new Random();
            osoba.m_strPESEL = lista_dodaj.pesel.Text;
            osoba.m_strName = lista_dodaj.imie.Text;
            osoba.m_strSecName = lista_dodaj.drugie_imie.Text;
            osoba.m_strSname = lista_dodaj.nazwisko.Text;
            osoba.m_strData = lista_dodaj.Data.Text;
            
            listview.Items.Add(new { m_strPESEL = osoba.m_strPESEL, m_srtName = osoba.m_strName, m_strSname = osoba.m_strSname});
        }

        private void New_Click(object sender, RoutedEventArgs e)
        {
            listview.Items.Clear();
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Pliki CSV z separatorem (,) |*.csv|Pliki CSV z separatorem (;) |*.csv";
            openFileDialog.Title = "Otwórz plik CSV";
            if (openFileDialog.ShowDialog() == true)
            {
                listview.Items.Clear();
                string filePath = openFileDialog.FileName;
                int selectedFilterIndex = openFileDialog.FilterIndex;
                string delimiter = ";";
                if (selectedFilterIndex == 1)
                {
                    delimiter = ",";
                }
                Encoding encoding = Encoding.UTF8;
                if (File.Exists(filePath))
                {
                    var lines = File.ReadAllLines(filePath, encoding);
                    foreach (var line in lines)
                    {
                        string[] columns = line.Split(delimiter);
                        if (columns != null)
                        {
                            Osoba uczen = new();
                            uczen.m_strPESEL = columns.ElementAtOrDefault(0);
                            uczen.m_strName = columns.ElementAtOrDefault(1);
                            uczen.m_strSecName = columns.ElementAtOrDefault(2);
                            uczen.m_strSname = columns.ElementAtOrDefault(3);
                            listview.Items.Add(uczen);
                        }
                    }
                }
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Pliki CSV z separatorem (,) |*.csv|Pliki CSV z separatorem (;) |*.csv";
            saveFileDialog.Title = "Zapisz jako plik CSV";
            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                string delimiter = ";";
                if (saveFileDialog.FilterIndex == 1)
                {
                    delimiter = ",";
                }
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (Osoba item in listview.Items)
                    {
                        var row = $"{item.m_strPESEL}{delimiter}{item.m_strName}" +
                        $"{delimiter}{item.m_strSecName}{delimiter}{item.m_strSurname}";
                        writer.WriteLine(row);
                    }
                }
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void NewRecord_Click(object sender, RoutedEventArgs e)
        {

        }

        private void RemoveSel_Click(object sender, RoutedEventArgs e)
        {
            while (listview.SelectedItems.Count > 0)
            {
                listview.Items.Remove(listview.SelectedItems[0]);
            }
        }
    }
}