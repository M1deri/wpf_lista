﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace projekt_wpf
{

    public class Osoba
    {
        public string? PESEL { get; set; }
        public string? Imie { get; set; }
        public string? drImie { get; set; }
        public string? Nazw { get; set; }
        public string? Urodz { get; set; }
        public string? Numer { get; set; }
        public string? Adres { get; set; }
        public string? Miejs { get; set; }
        public string? Kod { get; set; }
    }
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Dodaj_Click(object sender, RoutedEventArgs e)
        {
            Dodaj_osobe dodaj = new Dodaj_osobe();
            if (dodaj.ShowDialog() == true)
            {
                mainList.Items.Add(dodaj.OsobaDodana);
            }
        }
        private void Dodaj_osobe_Click(object sender, RoutedEventArgs e)
        {
            Dodaj_osobe dodaj = new Dodaj_osobe();
            Osoba uczen = new();
        }
        private void Open_Click(object sender, RoutedEventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Pliki CSV z separatorem (,) |*.csv|Pliki CSV z separatorem (;) |*.csv";
            openFileDialog.Title = "Otwórz plik CSV";

            if (openFileDialog.ShowDialog() == true)
            {
                mainList.Items.Clear();
                string filePath = openFileDialog.FileName;
                int selectedFilterIndex = openFileDialog.FilterIndex;
                string delimiter = ";";
                if (selectedFilterIndex == 1)
                {
                    delimiter = ",";
                }
                Encoding encoding = Encoding.UTF8;

                if (File.Exists(filePath))
                {
                    var lines = File.ReadAllLines(filePath, encoding);
                    foreach (var line in lines)
                    {
                        string[] columns = line.Split(delimiter);
                        if (columns != null)
                        {
                            Osoba uczen = new();
                            uczen.PESEL = columns.ElementAtOrDefault(0);
                            uczen.Imie = columns.ElementAtOrDefault(1);
                            uczen.drImie = columns.ElementAtOrDefault(2);
                            uczen.Nazw = columns.ElementAtOrDefault(3);
                            mainList.Items.Add(uczen);
                        }
                    }
                }
            }
        }
        private void Save_Click(object sender, RoutedEventArgs e)
        {

            SaveFileDialog saveFileDialog = new SaveFileDialog();

            saveFileDialog.Filter = "Pliki CSV z separatorem (,) |*.csv|Pliki CSV z separatorem (;) |*.csv";
            saveFileDialog.Title = "Zapisz jako plik CSV";

            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                string delimiter = ";";
                if (saveFileDialog.FilterIndex == 1)
                {
                    delimiter = ",";
                }

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (Osoba item in mainList.Items)
                    {
                        var row = $"{item.PESEL}{delimiter}{item.Imie}" +
                            $"{delimiter}{item.drImie}{delimiter}" +
                            $"{item.Nazw}{delimiter}{item.Urodz}" +
                            $"{delimiter}{item.Numer}{delimiter}" +
                            $"{item.Adres}{delimiter}{item.Miejs}" +
                            $"{delimiter}{item.Kod}";
                        writer.WriteLine(row);
                        
                    }
                }
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }


        private void RemoveSel_Click(object sender, RoutedEventArgs e)
        {
            while (mainList.SelectedItems.Count > 0)
            {
                mainList.Items.Remove(mainList.SelectedItems[0]);
            }
        }

        private void O_programie_Click(object sender, RoutedEventArgs e)
        {
            O_programie_w p = new O_programie_w();
            p.ShowDialog();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void NewRecord_Click(object sender, RoutedEventArgs e)
        {
            mainList.Items.Clear();
        }
    }
}