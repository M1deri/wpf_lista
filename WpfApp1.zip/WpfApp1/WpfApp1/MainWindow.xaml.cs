﻿using Microsoft.Win32;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.IO;
namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }
        class Osoba
        {
            public string? m_strPESEL { get; set; }
            public string? m_strName { get; set; }
            public string? m_strSecName { get; set; }
            public string? m_strSname { get; set; }
            public string? m_strData { get; set; }
            public string? m_strTelefon { get; set; }
            public string? m_strAdres { get; set; }
            public string? m_strMiejsce { get; set; }
            public string? m_strKod { get; set; }

            //public Osoba()
            //{
            //    m_strPESEL = "00000000000";
            //    m_strName = "";
            //    m_strSecName = "";
            //    m_strSname = "";
            //    m_strData = "";
            //    m_strTelefon = "";
            //    m_strAdres = "";
            //    m_strMiejsce = "";
            //    m_strKod = "";
            //}
        }
        private void New_Click(object sender, RoutedEventArgs e)
        {
            listview.Items.Clear();
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Pliki CSV z separatorem (,) |*.csv|Pliki CSV z separatorem (;) |*.csv";
            openFileDialog.Title = "Otwórz plik CSV";
            if (openFileDialog.ShowDialog() == true)
            {
                listview.Items.Clear();
                string filePath = openFileDialog.FileName;
                int selectedFilterIndex = openFileDialog.FilterIndex;
                string delimiter = ";";
                if (selectedFilterIndex == 1)
                {
                    delimiter = ",";
                }
                Encoding encoding = Encoding.UTF8;
                if (File.Exists(filePath))
                {
                    var lines = File.ReadAllLines(filePath, encoding);
                    foreach (var line in lines)
                    {
                        string[] columns = line.Split(delimiter);
                        if (columns != null)
                        {
                            Osoba uczen = new();
                            uczen.m_strPESEL = columns.ElementAtOrDefault(0);
                            uczen.m_strName = columns.ElementAtOrDefault(1);
                            uczen.m_strSecName = columns.ElementAtOrDefault(2);
                            uczen.m_strSname = columns.ElementAtOrDefault(3);
                            listview.Items.Add(uczen);
                        }
                    }
                }
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Pliki CSV z separatorem (,) |*.csv|Pliki CSV z separatorem (;) |*.csv";
            saveFileDialog.Title = "Zapisz jako plik CSV";
            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                string delimiter = ";";
                if (saveFileDialog.FilterIndex == 1)
                {
                    delimiter = ",";
                }
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (Osoba item in listview.Items)
                    {
                        var row = $"{item.m_strPESEL}{delimiter}{item.m_strName}" +
                        $"{delimiter}{item.m_strSecName}{delimiter}{item.m_strSname}";
                        writer.WriteLine(row);
                    }
                }
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void NewRecord_Click(object sender, RoutedEventArgs e)
        {
            Dodaj_lista lista_dodaj = new Dodaj_lista();
            lista_dodaj.ShowDialog();
            Osoba osoba = new Osoba();
            var rnd = new Random();
            osoba.m_strPESEL = lista_dodaj.pesel.Text;
            osoba.m_strName = lista_dodaj.imie.Text;
            osoba.m_strSecName = lista_dodaj.drugie_imie.Text;
            osoba.m_strSname = lista_dodaj.nazwisko.Text;
            osoba.m_strData = lista_dodaj.Data.Text;
            osoba.m_strTelefon = lista_dodaj.Telefon.Text;
            osoba.m_strAdres = lista_dodaj.Adres.Text;
            osoba.m_strMiejsce = lista_dodaj.Miejsce.Text;
            osoba.m_strKod = lista_dodaj.Kod.Text;

            bool czyDobrze = true;
            int[] wagi = { 1, 3, 7, 9, 1, 3, 7, 9, 1, 3 };
            int suma = 0;

            for (int i = 0; i < 10; i++)
            {
                suma += (osoba.m_strPESEL[i] - '0') * wagi[i];
            }
            
            int rok = int.Parse(osoba.m_strPESEL.Substring(0, 2));
            int miesiac = int.Parse(osoba.m_strPESEL.Substring(2, 2));
            int dzien = int.Parse(osoba.m_strPESEL.Substring(4, 2));

            int wiek = 0;
            int sumaKontrolna = (10 - (suma % 10)) % 10;
            if (
                string.IsNullOrWhiteSpace(osoba.m_strPESEL) ||
                string.IsNullOrWhiteSpace(osoba.m_strName) ||
                string.IsNullOrWhiteSpace(osoba.m_strSecName) ||
                string.IsNullOrWhiteSpace(osoba.m_strSname) ||
                string.IsNullOrWhiteSpace(osoba.m_strData) ||
                string.IsNullOrWhiteSpace(osoba.m_strTelefon) ||
                string.IsNullOrWhiteSpace(osoba.m_strAdres) ||
                string.IsNullOrWhiteSpace(osoba.m_strMiejsce) ||
                string.IsNullOrWhiteSpace(osoba.m_strKod)
              )
            {
                lista_dodaj.pesel.Background = Brushes.Red;
                lista_dodaj.imie.Background = Brushes.Red;
                lista_dodaj.drugie_imie.Background = Brushes.Red;
                lista_dodaj.nazwisko.Background = Brushes.Red;
                lista_dodaj.Data.Background = Brushes.Red;
                lista_dodaj.Telefon.Background = Brushes.Red;
                lista_dodaj.Adres.Background = Brushes.Red;
                lista_dodaj.Miejsce.Background = Brushes.Red;
                lista_dodaj.Kod.Background = Brushes.Red;
            }
            else
            {
                czyDobrze = true;
            }
            if (string.IsNullOrWhiteSpace(osoba.m_strPESEL) || osoba.m_strPESEL.Length != 11 || !osoba.m_strPESEL.All(char.IsDigit))
            {
                lista_dodaj.pesel.Background = Brushes.Red;
            }
            else
            {
                czyDobrze = true;
            }
            if(sumaKontrolna != (osoba.m_strPESEL[10] - '0'))
            {
                lista_dodaj.pesel.Background = Brushes.Red;
            }
            else
            {
                czyDobrze = true;
            }
            if (miesiac >= 1 && miesiac <= 12)
                wiek = 1900;
            else if (miesiac >= 21 && miesiac <= 32)
            {
                wiek = 2000;
                miesiac -= 20;
            }
            else if (miesiac >= 41 && miesiac <= 52)
            {
                wiek = 2100;
                miesiac -= 40;
            }
            else if (miesiac >= 61 && miesiac <= 72)
            {
                wiek = 2200;
                miesiac -= 60;
            }
            else if (miesiac >= 81 && miesiac <= 92)
            {
                wiek = 1800;
                miesiac -= 80;
            }
            else
            {
                czyDobrze = false;
            }
            DateTime dataZPesel;
            try
            {
                dataZPesel = new DateTime(wiek + rok, miesiac, dzien);
            }
            catch
            {
                czyDobrze =  false;
                wiek = 0;
            }
            if (czyDobrze == true)
            {
                listview.Items.Add(new
                {
                    m_strPESEL = osoba.m_strPESEL,
                    m_srtName = osoba.m_strName,
                    m_strSecName = osoba.m_strSecName,
                    m_strSname = osoba.m_strSname,
                    m_strData = osoba.m_strData,
                    m_strAdres = osoba.m_strAdres,
                    m_strMiejsce = osoba.m_strMiejsce,
                    m_strKod = osoba.m_strKod
                });
            }
            else
            {
                lista_dodaj.dodaj.Background = Brushes.Red;
            }
        }

        private void RemoveSel_Click(object sender, RoutedEventArgs e)
        {
            while (listview.SelectedItems.Count > 0)
            {
                listview.Items.Remove(listview.SelectedItems[0]);
            }
        }
        
        

    }
}