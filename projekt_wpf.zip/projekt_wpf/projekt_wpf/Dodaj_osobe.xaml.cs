﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace projekt_wpf
{
    public partial class Dodaj_osobe : Window
    {
        private bool zmieniono = false;
        public Osoba OsobaDodana { get; private set; }


        public Dodaj_osobe()
        {
            InitializeComponent();
            foreach (var child in LogicalTreeHelper.GetChildren(this))
            {
                if (child is TextBox textbox)
                    textbox.TextChanged += (s, e) => zmieniono = true;
            }

            UrodzDatePicker.SelectedDateChanged += (s, e) => zmieniono = true;
        }
       
        private void DodajButton_Click(object sender, RoutedEventArgs e)
        {
            if (!WalidujDane())
                return;

            string pesel = PESELTextBox.Text.Trim();
            string imie = FormatTekstu(ImieTextBox.Text);
            string drImie = FormatTekstu(DrImieTextBox.Text);
            string nazw = FormatTekstu(NazwTextBox.Text);
            string dataUrodz = UrodzDatePicker.SelectedDate.Value.ToString("yyyy-MM-dd");
            string numer = OczyscNumer(NumerTextBox.Text);
            string adres = FormatTekstu(AdresTextBox.Text);
            string miejs = FormatTekstu(MiejsTextBox.Text);
            string kod = KodTextBox.Text.Trim();

            if (!PeselZgodnyZData(pesel, UrodzDatePicker.SelectedDate.Value))
            {
                MessageBox.Show("PESEL nie zgadza się z datą urodzenia!", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            OsobaDodana = new Osoba()
            {
                PESEL = pesel,
                Imie = imie,
                drImie = drImie,
                Nazw = nazw,
                Urodz = dataUrodz,
                Numer = numer,
                Adres = adres,
                Miejs = miejs,
                Kod = kod
            };

            DialogResult = true;
            Close();
        }

        private void WyjdzButton_Click(object sender, RoutedEventArgs e)
        {
            if (zmieniono)
            {
                var result = MessageBox.Show("Czy na pewno chcesz wyjść bez zapisywania?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.No)
                    return;
            }
            Close();
        }
        private bool WalidujDane()
        {
            bool poprawne = true;

            poprawne &= WalidujPole(PESELTextBox, t => t.Length == 11 && Regex.IsMatch(t, @"^\d{11}$"));
            poprawne &= WalidujPole(ImieTextBox, t => !string.IsNullOrWhiteSpace(t));
            poprawne &= WalidujPole(NazwTextBox, t => !string.IsNullOrWhiteSpace(t));
            poprawne &= WalidujPole(AdresTextBox, t => !string.IsNullOrWhiteSpace(t));
            poprawne &= WalidujPole(MiejsTextBox, t => !string.IsNullOrWhiteSpace(t));
            poprawne &= WalidujPole(KodTextBox, t => Regex.IsMatch(t, @"^\d{2}-\d{3}$"));
            poprawne &= WalidujPole(UrodzDatePicker, dp => dp.SelectedDate != null);

            return poprawne;
        }

        private bool WalidujPole(TextBox textBox, Func<string, bool> warunek)
        {
            if (!warunek(textBox.Text.Trim()))
            {
                textBox.BorderBrush = Brushes.Red;
                return false;
            }
            else
            {
                textBox.ClearValue(Border.BorderBrushProperty);
                return true;
            }
        }

        private bool WalidujPole(DatePicker datePicker, Func<DatePicker, bool> warunek)
        {
            if (!warunek(datePicker))
            {
                datePicker.BorderBrush = Brushes.Red;
                return false;
            }
            else
            {
                datePicker.ClearValue(Border.BorderBrushProperty);
                return true;
            }
        }

        private string OczyscNumer(string numer)
        {
            numer = Regex.Replace(numer, @"\s+", "");
            if (!numer.StartsWith("+"))
                numer = "+48" + numer;
            return numer;
        }

        private bool PeselZgodnyZData(string pesel, DateTime dataUrodzenia)
        {
            string rok = dataUrodzenia.Year.ToString("D4").Substring(2, 2);
            string miesiac = dataUrodzenia.Month.ToString("D2");
            string dzien = dataUrodzenia.Day.ToString("D2");

            string peselRok = pesel.Substring(0, 2);
            string peselMiesiac = pesel.Substring(2, 2);
            string peselDzien = pesel.Substring(4, 2);

            if (dataUrodzenia.Year >= 2000)
            {
                miesiac = (dataUrodzenia.Month + 20).ToString("D2");
            }

            return peselRok == rok && peselMiesiac == miesiac && peselDzien == dzien;
        }

        private string FormatTekstu(string tekst)
        {
            tekst = tekst.Trim();
            if (string.IsNullOrWhiteSpace(tekst))
                return tekst;
            return char.ToUpper(tekst[0]) + tekst.Substring(1).ToLower();
        }
    }
}
